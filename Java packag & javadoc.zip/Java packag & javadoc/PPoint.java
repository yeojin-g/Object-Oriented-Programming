package kr.ac.kookmin.cs;
/**
	@author yeojin
	@version -
 */
public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    /**
     * This method return xA(getter method)
    	@return This method return xA
     */
    public int getX() {
        return xA;
    }
    /**
     * This method return yA(getter method)
		@return This method return yA
     */
    public int getY() {
        return yA;
    }
}
